pars1.c has been renamed pars1c.c to avoid conflicts with makefile.
